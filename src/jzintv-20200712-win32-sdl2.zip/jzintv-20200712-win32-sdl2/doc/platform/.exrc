set textmode=dos
