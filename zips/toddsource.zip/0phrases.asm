;; ======================================================================== ;;
;;  IV_PHRASE_TBL -- These are phrases that will be spoken.                 ;;
;; ======================================================================== ;;

IV_PHRASE_TBL PROC
            DECLE  PHRASE.title       ; 43
            DECLE  PHRASE.zero        ; 44
            DECLE  PHRASE.one         ; 45
            DECLE  PHRASE.two         ; 46
            DECLE  PHRASE.three       ; 47
            DECLE  PHRASE.four        ; 48
            DECLE  PHRASE.five        ; 49
            DECLE  PHRASE.six         ; 50
            DECLE  PHRASE.seven       ; 51
            DECLE  PHRASE.eight       ; 52
            DECLE  PHRASE.nine        ; 53
            DECLE  PHRASE.ten         ; 54
            DECLE  PHRASE.eleven      ; 55
            DECLE  PHRASE.twelve      ; 56
            DECLE  PHRASE.thirteen    ; 57
            DECLE  PHRASE.fourteen    ; 58
            DECLE  PHRASE.fifteen     ; 59
            DECLE  PHRASE.sixteen     ; 60
            DECLE  PHRASE.seventeen   ; 61
            DECLE  PHRASE.eighteen    ; 62
            DECLE  PHRASE.nineteen    ; 63
            DECLE  PHRASE.twenty      ; 64
            DECLE  PHRASE.thirty      ; 65
            DECLE  PHRASE.forty       ; 66
            DECLE  PHRASE.fifty       ; 67
            DECLE  PHRASE.sixty       ; 68
            DECLE  PHRASE.seventy     ; 69
            DECLE  PHRASE.eighty      ; 70
            DECLE  PHRASE.ninety      ; 71
            DECLE  PHRASE.hundred     ; 72
            DECLE  PHRASE.thousand    ; 73
            DECLE  PHRASE.million     ; 74

            DECLE  PHRASE.letsplay    ; 75
            DECLE  PHRASE.getset      ; 76
            DECLE  PHRASE.start       ; 77
            DECLE  PHRASE.readygo     ; 78
            DECLE  PHRASE.gameover    ; 79
            DECLE  PHRASE.ok          ; 80
            DECLE  PHRASE.good        ; 81
            DECLE  PHRASE.great       ; 82
            DECLE  PHRASE.super       ; 83
            DECLE  PHRASE.awesome     ; 84
            DECLE  PHRASE.expert      ; 85
            DECLE  PHRASE.wow         ; 86
            DECLE  PHRASE.final       ; 87
            DECLE  PHRASE.score       ; 88
            DECLE  PHRASE.baseball    ; 89
            DECLE  PHRASE.basket      ; 90
            DECLE  PHRASE.hockey      ; 91
            DECLE  PHRASE.soccer      ; 92
            DECLE  PHRASE.tennis      ; 93

            ENDP

PHRASE      PROC
@@title:
            DECLE       RESROM.pa2

            DECLE       _TT2, _AE1, _GG3, RESROM.pa1                                   ; tag
            DECLE       _AX, _LL, _AO, _AO, _NG1, _GG2, RESROM.pa2                     ; along
            DECLE       _TT2, _AO, _AO, RESROM.pa1, _DD1, RESROM.pa2                   ; todd
            DECLE       _TH, _RR1, _IY, RESROM.pa2                                     ; three
            DECLE       0
@@zero:
            DECLE  _ZZ, _YR, _OW
            DECLE  RESROM.pa1
            DECLE  0
@@one:
            DECLE  _WH, _AX, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@two:
            DECLE  _TT2, _UW2
            DECLE  RESROM.pa1
            DECLE  0
@@three:
            DECLE  _TH, _RR1, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@four:
            DECLE  _FF, _FF, _OR
            DECLE  RESROM.pa1
            DECLE  0
@@five:
            DECLE  _FF, _FF, _AY, _VV
            DECLE  RESROM.pa1
            DECLE  0
@@six:
            DECLE  _SS, _SS, _IH, _IH, _PA3, _KK2, _SS
            DECLE  RESROM.pa1
            DECLE  0
@@seven:
            DECLE  _SS, _SS, _EH, _EH, _VV, _IH, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@eight:
            DECLE  _EY, _PA3, _TT2
            DECLE  RESROM.pa1
            DECLE  0
@@nine:
            DECLE  _NN1, _AA, _AY, _PA3, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@ten:
            DECLE  _TT2, _EH, _EH, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@eleven:
            DECLE  _IH, _LL, _EH, _EH, _VV, _IH, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@twelve:
            DECLE  _TT2, _WH, _EH, _EH, _LL, _VV
            DECLE  RESROM.pa1
            DECLE  0
@@thirteen:
            DECLE  _TH, _ER1, _PA2, _PA3, _TT2, _IY, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@fourteen:
            DECLE  _FF, _OR, _PA2, _PA3, _TT2, _IY, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@fifteen:
            DECLE  _FF, _IH, _FF, _PA2, _PA3, _TT2, _IY, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@sixteen:
            DECLE  _SS, _SS, _IH, _PA3, _KK2, _SS, _PA2, _PA3, _TT2, _IY, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@seventeen:
            DECLE  _SS, _SS, _EH, _VV, _TH, _NN1, _PA2, _PA3, _TT2, _IY, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@eighteen:
            DECLE  _EY, _PA2, _PA3, _TT2, _IY, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@nineteen:
            DECLE  _NN1, _AY, _NN1, _PA2, _PA3, _TT2, _IY, _NN1
            DECLE  RESROM.pa1
            DECLE  0
@@twenty:
            DECLE  _TT2, _WH, _EH, _EH, _NN1, _PA2, _PA3, _TT2, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@thirty:
            DECLE  _TH, _ER2, _PA2, _PA3, _TT2, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@forty:
            DECLE  _FF, _OR, _PA3, _TT2, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@fifty:
            DECLE  _FF, _FF, _IH, _FF, _FF, _PA2, _PA3, _TT2, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@sixty:
            DECLE  _SS, _SS, _IH, _PA3, _KK2, _SS, _PA2, _PA3, _TT2, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@seventy:
            DECLE  _SS, _SS, _EH, _VV, _IH, _NN1, _PA2, _PA3, _TT2, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@eighty:
            DECLE  _EY, _PA3, _TT2, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@ninety:
            DECLE  _NN1, _AY, _NN1, _PA3, _TT2, _IY
            DECLE  RESROM.pa1
            DECLE  0
@@hundred:
            DECLE  _HH2, _AX, _AX, _NN1, _PA2, _DD2, _RR2, _IH, _IH, _PA1, _DD1
            DECLE  RESROM.pa1
            DECLE  0
@@thousand:
            DECLE  _TH, _AA, _AW, _ZZ, _SS, _AE1, _NN1, _DD1
            DECLE  RESROM.pa1
            DECLE  0
@@million:
            DECLE  _MM, _IH, _IH, _LL, _YY1, _AX, _NN1
            DECLE  RESROM.pa1
            DECLE  0

;------------------------------------------------------------------------------
; Add game phrases here
;------------------------------------------------------------------------------

@@letsplay:
            DECLE  _LL, _EH, _EH, _TT2, _SS                                       ; lets
            DECLE  RESROM.pa2
            DECLE  _PP, _LL, _EH, _EY                                             ; play
            DECLE  0

@@getset:
            DECLE  _GG1, _GG1, _EH, _TT2                                           ; get
            DECLE  RESROM.pa2
            DECLE  _SS, _SS, _EH, _TT2                                             ; set
            DECLE  0

@@start:
            DECLE  _SS, _PA3, _TT2, _AR, _PA3, _TT2                                ; start
            DECLE  0

@@readygo:
            DECLE  _RR1, _EH, _EH, _PA1, _DD2, _IY                                 ; ready
            DECLE  RESROM.pa3
            DECLE  _GG2, _UH, _OW                                                  ; go
            DECLE  0

@@gameover:
            DECLE  RESROM.pa2
            DECLE  _GG3, _EY, _MM                                                 ; game
            DECLE  RESROM.pa2
            DECLE  _OW, _VV, _PA1, _ER1                                           ; over
            DECLE  RESROM.pa4
            DECLE  0

@@ok:
            DECLE  RESROM.pa2
            DECLE  _OW, _KK1, _EH, _EY                                            ; ok
            DECLE  RESROM.pa2
            DECLE  0

@@good:
            DECLE  RESROM.pa2
            DECLE  _GG2, _UH, _UH, _DD1                                           ; good
            DECLE  RESROM.pa2
            DECLE  0

@@great:
            DECLE  RESROM.pa2
            DECLE  _GG3, _RR1,  _EY, _TT2                                         ; great
            DECLE  RESROM.pa2
            DECLE  0

@@super:
            DECLE  RESROM.pa2
            DECLE  _SS, _UW1, _PA1, _PP, _ER1                                     ; super
            DECLE  RESROM.pa2
            DECLE  0

@@awesome:
            DECLE  RESROM.pa2
            DECLE  _AO, _SS, _SS, _PA1, _UH, _MM                                  ; awesome
            DECLE  RESROM.pa2
            DECLE  0

@@expert:
            DECLE  RESROM.pa2
            DECLE  _EH, _KK1, _SS, _PA1, _PP, _ER1, _TT2                          ; expert
            DECLE  RESROM.pa2
            DECLE  0

@@wow:
            DECLE  RESROM.pa2
            DECLE  _WW, _AW, _WW, RESROM.pa4, _AX, _NG1, _PA3, _BB2, _AO, _PA1, _LL, _IY, _VV, _PA1, _AX, _BB1, _PA1, _UH, _LL   ; wow unbeleivable
            DECLE  RESROM.pa2
            DECLE  0

@@final:
            DECLE  RESROM.pa2
            DECLE  _FF, _AA, _AY, _PA1, _NN2, _AX, _LL, _LL                       ; final
            DECLE  RESROM.pa2
            DECLE  0

@@score:
            DECLE  RESROM.pa1
            DECLE  _SS, _PA1, _KK2, _OW, _OR                                      ; score
            DECLE  RESROM.pa4                                                     ; pause before reading the numbers
            DECLE  0

@@tennis:
            DECLE  _TT2, _EH, _EH, _NN1, _IH, _IH, _SS, _SS, _PA2                 ; tennis
            DECLE  RESROM.pa1
            DECLE  0

@@hockey:
            DECLE  _HH2, _PA2, _AA, _AX, _PA2, _KK1, _IY                          ; hockey
            DECLE  RESROM.pa1
            DECLE  0

@@soccer:
            DECLE  _SS, _PA1, _AO, _AO, _PA2, _KK1, _ER1, _PA2                    ; soccer
            DECLE  RESROM.pa1
            DECLE  0

@@basket:
            DECLE  _BB2, _AE1, _AE1, _PA2, _SS, _KK1, _EH, _TT2, _BB1, _AO, _AO, _LL; basketball
            DECLE  RESROM.pa1
            DECLE  0

@@baseball:
            DECLE  _BB2, _EY, _SS, _BB1, _AO, _AO, _PA2, _LL                      ; baseball
            DECLE  RESROM.pa1
            DECLE  0



            ENDP

